#include<iostream>
#include<string>
using namespace std;

const int Maxlen = 20;
const int Max = 27;

struct NodeType
{
	char data[Maxlen];
	NodeType* next;
};
void RadixSort(NodeType*& p, int r, int d)
{
	NodeType* head[Max];
	NodeType* tail[Max];
	NodeType* t = new NodeType;
	for (int i = d - 1; i > -1; i--)
	{
		for (int j = 0; j < r; j++)
			head[j] = tail[j] = NULL;
		while (p != NULL)
		{
			int k;
			if (p->data[i] == '\0')k = 0;
			else k = p->data[i] - 'a' + 1;
			if (head[k] == NULL)
			{
				head[k] = p; tail[k] = p;
			}
			else
			{
				tail[k]->next = p; tail[k] = p;
			}
			p = p->next;
		}
		p = NULL;
		for (int j = 0; j < r; j++)
		{
			if (head[j] != NULL)
			{
				if (p == NULL)
				{
					p = head[j]; t = tail[j];
				}
				else
				{
					t->next = head[j]; t = tail[j];
				}
			}
		}
		t->next = NULL;
	}
	t = NULL; delete t;
}

int main()
{
	string str; int n;
	cout << "How many words do you want to sort: ";
	cin >> n; NodeType* p = new NodeType; 
	p->next = NULL;
	for (int i = 0; i < n; i++)
	{
		cout << i + 1 << ": "; cin >> str;
		NodeType* q = new NodeType;
		for (int j = 0; j < Maxlen; j++)
		{
			if (j < str.length())
				q->data[j] = str[j];
			else q->data[j] = '\0';
		}
		q->next = p->next; p->next = q;
		q = NULL; delete q;
	}
	NodeType* q = p;
	p = p->next; delete q;
	RadixSort(p, 27, Maxlen);
	cout << endl << "The lexicographic order is: " << endl;
	int k = 0;
	while (p != NULL)
	{
		cout << ++k << ": " << p->data << endl;
		NodeType* q = p;
		p = p->next; delete q;
	}
	delete p; 
	return 0;
}