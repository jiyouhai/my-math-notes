//#include<iostream>
//
//using namespace std;
//const int MAXV = 31;
//int visited[MAXV] = { 0 };
//
//struct ArcNode															//�߽ڵ�����
//{
//	int adjvex;
//	ArcNode* nextarc;
//	int weight;
//};
//struct VNode															//ͷ�������
//{
//	int data;
//	ArcNode* firstarc;
//};
//struct AdjGraph															//�ڽӱ�����
//{
//	VNode adjlist[MAXV];												//ͷ�������
//	int n, e;															//������n����e
//};
//
//void CreatAdj(AdjGraph*& G, int A[MAXV][MAXV], int n, int e);			//�����ڽӱ�
//void DispAdj(AdjGraph* G);												//����ڽӱ�
//void DestroyAdj(AdjGraph*& G);											//�����ڽӱ�
//void FindExpPath(AdjGraph* G, int u, int v, int path[], int d, int x, int a[], int y, int b[]);	//�ҷ���Ҫ���·��
//
//////////////////////////////////////////////////////////////////////////////////////
//int main()
//{
//	int A[MAXV][MAXV] = {
//	//	 0,1,2,3,4,5,6,7,8,9,0,1,2,3,4
//		{0,1,1,1,1,0,0,0,0,0,0,0,0,0,0},//0
//		{1,0,0,0,0,0,1,0,1,0,0,0,0,0,0},//1
//		{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},//2
//		{1,0,0,0,0,0,1,0,0,0,0,0,0,0,0},//3
//		{1,0,0,0,0,0,0,1,0,0,0,0,0,0,0},//4
//		{0,0,0,0,0,0,0,0,1,1,0,0,0,0,0},//5
//		{0,1,0,1,0,0,0,1,0,1,0,0,0,0,0},//6
//		{0,0,0,0,1,0,1,0,0,0,1,1,0,0,0},//7
//		{0,1,0,0,0,1,0,0,0,0,0,0,1,0,0},//8
//		{0,0,0,0,0,1,1,0,0,0,1,0,1,0,0},//9
//		{0,0,0,0,0,0,0,1,0,1,0,0,0,1,0},//10
//		{0,0,0,0,0,0,0,1,0,0,0,0,0,1,0},//11
//		{0,0,0,0,0,0,0,0,1,1,0,0,0,0,1},//12
//		{0,0,0,0,0,0,0,0,0,0,1,1,0,0,1},//13
//		{0,0,0,0,0,0,0,0,0,0,0,0,1,1,0},//14
//	};
//	AdjGraph* G; int n = 15; int e = 20;
//	CreatAdj(G, A, n, e);
//	cout << "���������յ㣬�ÿո����" << endl; 
//	int u, v; cin >> u >> v;
//	cout << "����ؾ������" << endl;
//	int x; cin >> x; 
//	int* a = new int[x];
//	cout << "����һ��ؾ��㣬�ÿո����" << endl;
//	for (int i = 0; i < x; i++)cin >> a[i];
//	cout << "����رܵ����" << endl;
//	int y; cin >> y; 
//	int* b = new int[y];
//	cout << "����һ��رܵ㣬�ÿո����" << endl;
//	for (int i = 0; i < y; i++)cin >> b[i];
//	//int u = 0, v = 14;
//	//int x = 2;
//	//int* a = new int[x];
//	//a[0] = 1; a[1] = 5;
//	//int y = 3;
//	//int* b = new int[y];
//	//b[0] = 3; b[1] = 6; b[2] = 10;
//	int path[15];
//	FindExpPath(G, u, v, path, -1, x, a, y, b);
//	DestroyAdj(G); delete[] a; delete[] b;
//	return 0;
//}
//////////////////////////////////////////////////////////////////////////////////////
//
//void CreatAdj(AdjGraph*& G, int A[MAXV][MAXV], int n, int e)			//�����ڽӱ�
//{
//	ArcNode* p;
//	G = new AdjGraph;
//	for (int i = 0; i < n; i++)G->adjlist[i].firstarc = NULL;
//	for (int i = 0; i < n; i++)
//		for (int j = n - 1; j >= 0; j--)
//			if (A[i][j] != 0 && A[i][j] != 32767)
//			{
//				p = new ArcNode;
//				p->adjvex = j;
//				p->weight = A[i][j];
//				p->nextarc = G->adjlist[i].firstarc;
//				G->adjlist[i].firstarc = p;
//			}
//	G->n = n; G->e = e;
//}
//void DispAdj(AdjGraph* G)												//����ڽӱ�
//{
//	ArcNode* p;
//	for (int i = 0; i < G->n; i++)
//	{
//		p = G->adjlist[i].firstarc;
//		cout << i << ": ";
//		while (p != NULL)
//		{
//			cout << p->adjvex << '[' << p->weight << ']' << "->";
//			p = p->nextarc;
//		}
//		cout << '^' << endl;
//	}
//}
//void DestroyAdj(AdjGraph*& G)											//�����ڽӱ�
//{
//	ArcNode* pre, * p;
//	for (int i = 0; i < G->n; i++)
//	{
//		pre = G->adjlist[i].firstarc;
//		if (pre != NULL)
//		{
//			p = pre->nextarc;
//			while (p != NULL)
//			{
//				delete pre;
//				pre = p; p = p->nextarc;
//			}
//			delete pre;
//		}
//		
//	}
//	delete G;
//}
//void FindExpPath(AdjGraph* G, int u, int v, int path[], int d, int x, int a[], int y, int b[])		//�ҷ���Ҫ���·��
//{
//	int w; ArcNode* p;
//	d++; path[d] = u;
//	bool unfind = true;
//	for (int i = 0; i < y; i++)
//		if (u == b[i])
//		{
//			unfind = false; break;
//		}
//	if (unfind)
//	{
//		visited[u] = 1;
//		if (u == v)
//		{
//			int m = 0, n = 0;
//			for (int i = 0; i < x; i++)m += visited[a[i]];
//			if (m == x)
//			{
//				for (int i = 0; i <= d; i++)
//					cout << path[i] << "  ";
//				cout << endl;
//			}
//			visited[u] = 0;
//			return;
//		}
//		p = G->adjlist[u].firstarc;
//		while (p != NULL)
//		{
//			w = p->adjvex;
//			if (visited[w] == 0)
//				FindExpPath(G, w, v, path, d, x, a, y, b);
//			p = p->nextarc;
//		}
//		visited[u] = 0;
//	}
//}