#include<iostream>
using namespace std;
void jh( char*&ap, char*&bp)
{
    char*cp;
    cp=ap;
    ap=bp;
    bp=cp;
}
int main()
{
    char*ap="hello",*bp="how are you?";
    cout<<ap<<" "<<bp<<endl;
    jh(ap,bp);
    cout<<ap<<" "<<bp<<endl;
}
