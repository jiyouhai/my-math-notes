#include<iostream>
using namespace std;
    struct tbtnode
{
   char date;
   int ltag,rtag;
   tbtnode* lchild;
   tbtnode*rchild;
};
tbtnode*pre;
void creattbt(tbtnode*&b,char*str)
{
    tbtnode*st[50];
    tbtnode*p;
    int i=-1,j=0,k=0;
    char ch=str[j];
    while(ch!='\0')
    {
        switch(ch)
        {
        case '(':i++;st[i]=p;k=1;break;
        case ')':i--;break;
        case ',':k=2;break;
            default:p=new tbtnode;
            p->date=ch;
            p->lchild=p->rchild=NULL;
            if(b==NULL)
                b=p;
            else
            {
                if(k==1)
                    st[i]->lchild=p;
                    else
                       st[i]->rchild=p;
            }
        }
        j++;
        ch=str[j];
    }
}

void thread(tbtnode*&b)
{
    if(b!=NULL)
    { thread(b->lchild);
        if(b->lchild==NULL)
        {
            b->ltag=1;
            b->lchild=pre;
        }
        else
            b->ltag=0;
           if(pre->rchild==NULL)
        {
            pre->rtag=1;
            pre->rchild=b;
        }
        else
            pre->rtag=0;
            pre=b;

            thread(b->rchild);
    }
}
tbtnode*creatthread(tbtnode*&b)
{
tbtnode*root=new tbtnode;
root->ltag=0;root->rtag=1;
root->rchild=b;
if(b==NULL)
root->lchild=root;
else
   {root->lchild=b;
   pre=root;
thread(b);
pre->rchild=root;
pre->rtag=1;
root->rtag=1;

  root->rchild=pre; }
   return root;
}
void puttbt(tbtnode*root)
{
    tbtnode*p=root->lchild;
    while(p!=root)
    {while(p->ltag==0)p=p->lchild;
    cout<<p->date;
    while(p->rtag==1&&p->rchild!=root)
    {
        p=p->rchild;
        cout<<p->date;
    }
    p=p->rchild;
}
}
int main()
{
char a[100];
cout<<"����Ҫ�������Ķ�������";
cin>>a;
tbtnode * b=NULL;
creattbt(b,a);
tbtnode*root;
root=creatthread(b);
puttbt(root);

}
