#include<iostream>

using namespace std;
void fun1(float a[][4],int i,int j)
{
    float SumGradeOfStudent[5]={0,0,0,0,0},smax=0,SumGradeOfclass[4]={0,0,0,0},cmax=0;
 for(int i=0;i<5;i++)
   for(int j=0;j<4;j++)
SumGradeOfStudent[i]+=a[i][j];
    for(int i=0;i<5;i++)
    {
        if(SumGradeOfStudent[i]>smax)
        smax=SumGradeOfStudent[i];
    }
    cout<<"the student of highest grades is:";
 for(int i=0;i<5;i++)
    {
        if(SumGradeOfStudent[i]==smax)
        cout<<"student"<<i+1<<" ";
    }
    cout<<endl;
    for(int i=0;i<4;i++)
   for(int j=0;j<5;j++)
SumGradeOfclass[i]+=a[j][i];
    for(int i=0;i<4;i++)
    {
        if(SumGradeOfclass[i]>cmax)
        cmax=SumGradeOfclass[i];
    }
    cout<<"the class of highest grades is:";
 for(int i=0;i<4;i++)
    {
        if(SumGradeOfclass[i]==cmax)
        cout<<"class"<<i+1<<" ";
    }
       cout<<endl;

}
void fun2(float a[][4],int i,int j)
{
   for(int i=0;i<5;i++)
   {
       for(int j=0;j<4;j++)
   {
       if(a[i][j]<60)
{cout<<"the student"<<i+1<<" has lost class. his each class's grade is:\n";
   for(int j=0;j<4;j++)
   {
       cout<<"class"<<j+1<<"'s grade is"<<a[i][j]<<"  ";
   }
   cout<<endl;
   break;
   }

   }
}
}

void fun3(float a[][4],int i,int j)
{
float w[4]={0,0,0,0};
for(int i=0;i<4;i++)
   for(int j=0;j<5;j++)
w[i]+=a[j][i];
for(int i=0;i<4;i++)
    cout<<"the class"<<i+1<<"'s avary grade is:"<<w[i]/5.0<<endl;
}
int main()
{
  float a[5][4];
 for(int i=0;i<5;i++)
   {
       for(int j=0;j<4;j++)
       {
           float b;
           cout<<"please cin the student"<<i+1<<"'s grade of class"<<j+1<<":";
           cin>>b;
           a[i][j]=b;
       }
   }
   fun1(a,5,4);
   fun2(a,5,4);
fun3(a,5,4);
}
