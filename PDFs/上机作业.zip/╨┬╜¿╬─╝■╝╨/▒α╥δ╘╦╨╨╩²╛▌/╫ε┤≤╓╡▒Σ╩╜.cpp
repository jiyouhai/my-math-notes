#include<iostream>
using namespace std;
void imax(int grade[][4],int h,int l)
{
  for(int j=0;j<l;j++)

  {
      int imax=0;

      {
         for(int i=0;i<h;i++)
           if(grade[i][j]>imax)
        imax=grade[i][j];

      }
       cout<<imax<<endl;
  }

}
int main()
{
    int a[3][4]={{68,77,73,86},{87,96,78,89},{90,70,81,86}};
  imax(a,3,4);
}
