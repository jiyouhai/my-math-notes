#include<iostream>
using namespace std;

int main()
{
    cout<<"\"how many students here?\""<<endl;
    cout<<"\"500\"";
}
