#include<iostream>

#include<iomanip>
using namespace std;

int main()
{
 cout<<setw(5)<<"*";
 for(int j=1;j<=9;j++)
    cout<<setw(5)<<j;
 cout<<endl;
 for(int i=1;i<=9;i++)
 {
     cout<<setw(5)<<i;
 for(int j=1;j<=i;j++)
    cout<<setw(5)<<i*j;
 cout<<endl;
 }
}
