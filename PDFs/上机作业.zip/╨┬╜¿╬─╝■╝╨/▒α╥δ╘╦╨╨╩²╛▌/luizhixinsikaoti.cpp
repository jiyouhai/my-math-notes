#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;
int factor(int a)
{
    double b=sqrt(a);
    for(int i=2;i<=b;i++)
    {
      if(!(a%i))
            {return 0;
            goto ed;
            }
    }
    return 1;
    ed:
        ;
}
int main()
{
    for(int i=3;i<10000;i++)
  {
      if(factor(i))
  {
      int f[10000];
  f[0]=1,f[1]=1;
  for(int j=2;j<10000;j++)
    f[j]=(f[j-1]+f[j-2])%i;
  for(int index=2;index<10000;index++)
  {
      if(f[index]==1)
      {
          if(f[index+1]==1)
           {
            cout<<setw(4)<<"k("<<i<<')'<<'='<<index;
            break;
           }
      }
  }
  }
  }

}
