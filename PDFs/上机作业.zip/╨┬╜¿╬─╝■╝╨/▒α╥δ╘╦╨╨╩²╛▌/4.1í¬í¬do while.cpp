#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;

int main()
{
 double x,a;
 do
 {cin>>x;
 a=x;
 double s=1;
 double n=1;
 do{s=s+a;
 a=(-1)*a*x/(n+1);
   n++;
 }while(fabs(a)>1e-8);
 cout<<setprecision(8)<<s<<endl;
 }while(1);

}
