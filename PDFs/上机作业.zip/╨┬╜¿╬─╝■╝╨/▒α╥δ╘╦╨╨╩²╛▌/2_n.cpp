#include<iostream>
#include<cmath>
using namespace std;

int main()
{

    int n,i;
    float w,num7,num8;
    unsigned long long  int a;
  for(n=3;n<30;n++)
  {num7=0,num8=0;
  i=0;
      a=(int)pow(2,n);

    while(a/(int)pow(10,i)!=0)
    {
        if((a/(int)pow(10,i))%10==7)
            num7++;
        if((a/(int)pow(10,i))%10==8)
            num8++;
        i++;
    }
    w=num7/num8;
    cout<<"  "<<w;
  }
  cout<<"����";

}
