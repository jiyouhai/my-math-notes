#include<iostream>
#include<math.h>
using namespace std;
int main()
{

    double x,a,c,y1,y2,y3;
    const double pi=3.1415926535;
    cin>>x>>a>>c;
    y1=sqrt(pow(sin(x),2.5));
    y2=1.0/2*(a*x+(a+x)/(4*a));
    y3=pow(c,pow(x,2))/sqrt(2*pi);
    cout<<y1<<endl <<y2<<endl<<y3;
}
