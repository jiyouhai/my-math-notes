#include<iostream>
using namespace std;
int main()
{ {
int a[5]={10,20,30,40,50};
int *p=&a[0];
p++;
cout<<*p<< " " ;
p+=3;
cout<<*p<< " ";
cout<<*p-- << " " ;
cout<<++*p<< endl; ;
} }
