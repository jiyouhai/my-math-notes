
#include <iostream>
using namespace std;
void cf(int x) { cout<<x<<endl; }
void cf(char* x) { cout<<x<<endl; }
void main()
{
char y=“a‟;
cf(y);
cf(“b”);
}
