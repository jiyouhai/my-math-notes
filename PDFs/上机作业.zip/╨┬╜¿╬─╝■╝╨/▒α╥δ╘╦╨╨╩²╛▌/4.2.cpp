#include<iostream>
using namespace std;

int main()
{
int s=0,n=5,a=1;

for(int i=1;i<=n;i++)
{
 a=a*i ;
 s=s+a;
}
cout<<s<<endl;
}
