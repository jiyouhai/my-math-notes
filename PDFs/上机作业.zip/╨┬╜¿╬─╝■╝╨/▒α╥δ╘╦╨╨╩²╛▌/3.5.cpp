#include<iostream>
using namespace std;
int main()
{
int x;
do{cin>>x;
if(!(x%3)&&!(x%5)&&!(x%7))
    cout<<"can be devided by 3,5,7"<<endl;
    else
        if(!(x%3)&&!(x%5))
        cout<<"can be devided by 3,5"<<endl;
    else
        if(!(x%5)&&!(x%7))
        cout<<"can be devided by 5,7"<<endl;
     else
        if(!(x%3)&&!(x%7))
        cout<<"can be devided by 3,7"<<endl;
        else
            if(!(x%3))
            cout<<"can be devided by 3"<<endl;
            else
        if(!(x%5))
            cout<<"can be devided by 5"<<endl;
            else
            if(!(x%7))
            cout<<"can be devided by 7"<<endl;
            else
                cout<<"can't be devided by any of 3,5,7"<<endl;}while(1);

}
