#include<iostream>

#include<iomanip>
using namespace std;

int main()
{
 int n;
do{cin>>n;
 for(int i=1;i<=n;i++)
 {
     cout<<setw(60-i)<<"#";
     for(int j=1;j<=2*(i-1);j++)
        cout<<"#";
     cout<<endl;
 }}while(1);
}
