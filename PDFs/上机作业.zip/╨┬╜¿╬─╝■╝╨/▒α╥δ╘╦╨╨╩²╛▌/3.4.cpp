#include<iostream>
using namespace std;
int main()
{
  double x;
  do{cin>>x;
  if(x>10)
        cout<<"error"<<endl;
    if(x>2&&x<=10)
    cout<<x*(x+2);

    if(x>-1&&x<=2)
    cout<<2*x;
 if(x<=-1)
    cout<<x-1;
  }while(1);

}
