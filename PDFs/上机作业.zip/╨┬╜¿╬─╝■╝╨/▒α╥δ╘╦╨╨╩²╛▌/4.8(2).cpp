#include<iostream>

#include<iomanip>
using namespace std;

int main()
{
 int n;
do{cin>>n;
 for(int i=1;i<=n;i++)
 {
     cout<<setw(2+i)<<"# ";
     for(int j=1;j<=(n-i);j++)
        cout<<"# ";
     cout<<endl;
 }}while(1);
}
