#include<iostream>
using namespace std;

int main()
{
long i = 0;
int* p =new int[100];
try{
while( p!=NULL )
{
i++;
p = new int[100];
}
}
catch(std::bad_alloc)
{
    ;
}
cout<<i ;

}
