#include<iostream>
#include<math.h>

using namespace std;

int main()
{
for(int n=100;n<1000;n++)
{
    if(pow(n%10,3)+pow((n%100-n%10)/10,3)+pow((n-n%100)/100,3)==n)
        cout<<n<<"        ";
}


}
