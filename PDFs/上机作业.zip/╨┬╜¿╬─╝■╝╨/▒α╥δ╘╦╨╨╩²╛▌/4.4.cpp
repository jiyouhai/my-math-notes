#include<iostream>
#include<math.h>

using namespace std;

int main()
{
 for(int n=1;n<=1000;n++)
 {
     int s=0;
     for(int i=1;i<n;i++)
     {
         if(!(n%i))
            s=s+i;
     }
     if(s==n)
        cout<<n<<"   ";
 }

}
