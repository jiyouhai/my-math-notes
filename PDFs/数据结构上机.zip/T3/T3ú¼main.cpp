#include <iostream>
#include <string>
#include<malloc.h>
#define maxl 100
#define MaxSize 100
using namespace std;


typedef struct yk//һ������ 
{
	char data[maxl];
	struct yk * next;
}yk; 


void px(yk * &p, int r, int d)//���� 
{
    yk *head[MaxSize],*tail[MaxSize],*t;
	int i,j,k;
    for(i=d-1; i>=0; i--)
    {
      	 	for(j=0;j<r;j++)
			head[j]=tail[j]=NULL;
			while(p!=NULL) 
			{
				if(p->data[i]>'z'||p->data[i]<'a')
					k=0;
				else
		    		k=p->data[i]-'a'+1;
				if(head[k]==NULL)
				{
					head[k]=p;tail[k]=p;
				}
				else
				{
					tail[k]->next=p;tail[k]=p;
				}
				p=p->next;
			}
		
			for(j=0;j<r;j++)//�ռ� 
				if(head[j]!=NULL)
				{	
					if(p==NULL)
					{p=head[j];t=tail[j];}
					else
					{t->next=head[j];t=tail[j];}
				}
			t->next=NULL;
    }
   
}
int main()
{
	int n;
	char a[6][maxl]={"zyjwy","abcdefgh","nhghne","sfgyr","snra","rrtar"};
    n=6;
	int i;
	int j;
	yk * p=(yk*)malloc(sizeof(yk));
	yk * L=p, * s,* q;
	for(i=0;i<n;i++)   
	{
		s=(yk*)malloc(sizeof(yk));
		for(j=0;j<maxl;j++)
			s->data[j]=a[i][j];
		L->next=s;
		L=s;
	}
    L->next=NULL;
    px(p,27,9);
	q=p->next;
	while(q!=NULL)
	{
	    cout<<q->data;
		cout<<' ';
		q=q->next;
	}
}
