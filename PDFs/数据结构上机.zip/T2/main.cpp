#include <iostream>
#include<string>
#include<malloc.h>
#define MAXV 15
#define INF 33333

using namespace std;

int visited[MAXV];
int n1;//��Ҫ������ĸ��� 
int n2;//���ܾ�����ĸ��� 
int bn[MAXV];//���ܾ��� 
int xy[MAXV];//��Ҫ���� 

//�߽�㣬ͷ��� 
typedef struct ANode
{
    int adjvex;
    struct ANode* nextarc;
    int weight;
}ArcNode;

typedef struct Vnode
{
    char data;
    ArcNode* firstarc;
}Vnode;

typedef struct AdjGragh
{
    Vnode adjlist[MAXV];
    int n, e;
}AdjGragh; 
//����ͼ�����ͼ������ͼ 
void CreateAdj(AdjGragh* &G, int A[MAXV][MAXV], int n, int e)
{
    int i, j;ArcNode* p;
    G = (AdjGragh*)malloc(sizeof(AdjGragh));
    for (i = 0;i < n;i++)
        G->adjlist[i].firstarc = NULL;
    for(i = 0;i < n;i++)
       {
		 for(j = n-1;j >=0;j--)
           {
			if (A[i][j] != 0 && A[i][j] != INF) 
            {
                p = (ArcNode*)malloc(sizeof(ArcNode));
                p->adjvex = j;
                p->weight=A[i][j];
                p->nextarc = G->adjlist[i].firstarc;
                G->adjlist[i].firstarc = p;
            }
           }
        }
    G->n = n;G->e = e;
}

void DispAdj(AdjGragh* G) 
{
    int i;ArcNode* p;
    for (i = 0;i < G->n;i++)
    {
        p = G->adjlist[i].firstarc;
        cout << i<<": ";
        while (p != NULL )
        {
            cout << p->adjvex<<"->";
            p = p->nextarc;
        }
        cout << "^" << endl;
    }
}

void DestroyAdj(AdjGragh*& G)
{
    int i;
    ArcNode* pre, * p;
    for (i = 0;i < G->n;i++)
    {
	
        pre = G->adjlist[i].firstarc;
        if (pre != NULL)
        {
            p = pre->nextarc;
            while (p != NULL)
            {
                free(pre);
                pre = p;p = p->nextarc;
            }
            free(pre);
        }
    }
    free(G);
}

//�ж��Ƿ�������� 
bool cond(int path[MAXV], int d)
{
    int m=0,M; 
    int n=0,N;
	int i,j;
    for (i=0;i<n1;i++)
    {
         M=1;
         for(j=0;j<=d;j++)
             if(path[j]==xy[i])
			 {
				 M=0;
				 break;
			 }
          m=M+m;
    }   
    for (i=0;i<n2;i++)
    {
         N=0;
         for (j=0;j<=d;j++)
             if (path[j] == bn[i])
             {
                N=1;
                break;
            }    
        n=N+n;    
    }    
     
      if(m==0 && n==0)
         return true;
      else
         return false;
}


//�ҳ����д�u��v�����м�·�������
void FindAllPath(AdjGragh* G, int u, int v, int path[],int d)  
{
	
	int w,i;ArcNode *p;
    d++;path[d]=u;
    visited[u]=1;
    if (u==v && cond(path, d))
	{cout<<"���:"<<path[0]<<"->";
       for (i=1;i<d;i++)
          cout<<path[i]<<"->";
          cout<<path[d]<<"(�յ�)";
       cout<<'\n';
    }

    p=G->adjlist[u].firstarc;
	while(p!=NULL)
	{
   	   	w=p->adjvex;
	    if(visited[w]==0 )
		   FindAllPath(G,w,v,path,d);
	  	p=p->nextarc;
	}
		visited[u]=0;
}

int main()
{
    int path[MAXV];
    int u=0 , v =10;
    int n = 15, e = 21;
//    cout<<"��������㣺"<<endl;
//	cin>>u;
//	cout<<"�������յ㣺"<<endl;
//	cin>>v;
    
    int A[MAXV][MAXV] = { {0,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
	                      {1,0,0,0,0,0,1,0,1,0,0,0,0,0,0},
						  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0}, 
						  {1,0,0,0,0,0,1,0,0,0,0,0,0,0,0},
						  {1,0,0,0,0,0,0,1,0,0,0,0,0,0,0}, 
						  {0,0,0,0,0,0,0,0,1,1,0,0,0,0,0},
						  {0,1,0,1,0,0,0,1,0,1,0,0,0,0,0}, 
						  {0,0,0,0,1,0,1,0,0,0,1,1,0,0,0},
                          {0,1,0,0,0,1,0,0,0,0,0,0,1,0,0}, 
						  {0,0,0,0,0,1,1,0,0,0,1,0,1,0,0},
                          {0,0,0,0,0,0,0,1,0,1,0,0,0,1,0},
						  {0,0,0,0,0,0,0,1,0,0,0,0,0,1,0},
                          {0,0,0,0,0,0,0,0,1,1,0,0,0,0,1}, 
						  {0,0,0,0,0,0,0,0,0,0,1,1,0,0,1},
                          {0,0,0,0,0,0,0,0,0,0,0,0,1,1,0} };

    cout<<"������һ����뾭���ĵ㣺(���롮�յ㡯��������)"<<endl;
	for(int x=0;x < 15;x++) 
	{cin>>xy[x];
	if(xy[x]==00)
	break; 
	}
	
	cout<<"������һ�鲻�ܾ����ĵ㣺(���롮16����������)"<<endl;
	for(int y=0;y < 15;y++) 
	{cin>>bn[y];
	if(bn[y]==00)
	break; 
	}
	
    n1=sizeof(xy)/sizeof(xy[0]);
	n2=sizeof(bn)/sizeof(bn[0]); 
    AdjGragh* G;
    CreateAdj(G, A, n, e);
    cout << "��"<<u<<"��"<<v<<"����������������·����"<<endl ;
    FindAllPath(G,u,v,path,-1);
    DestroyAdj(G);
    return 1;
}
